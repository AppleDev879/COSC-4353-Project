const users = [
    {
        fullname: "Carlos Molina",
        email: "carlosmolina@gmail.com",
        password: "Ca12345#"
    }
];

module.exports = {
    users
}